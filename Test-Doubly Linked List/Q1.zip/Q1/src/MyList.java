
import java.util.*;
import java.io.*;

public class MyList {

    Node head, tail;
    int size;

    MyList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    public void clear() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    void ftraverseFW(RandomAccessFile f) throws Exception {
        Node p = head;
        while (p != null) {
            f.writeBytes(p.info.ID + "-" + p.info.name + "-" + p.info.price + "     ");
            p = p.next;
        }

        f.writeBytes("\r\n");
    }

    void ftraverseBW(RandomAccessFile f) throws Exception {
        Node p = tail;
        while (p != null) {
            f.writeBytes(p.info.ID + "-" + p.info.name + "-" + p.info.price + "     ");
            p = p.pre;
        }

        f.writeBytes("\r\n");
    }

    void loadData(int k) {
        String[] a = Lib.readLineToStrArray("data.txt", k);
        String[] b = Lib.readLineToStrArray("data.txt", k + 1);
        String[] c = Lib.readLineToStrArray("data.txt", k + 2);
        int n = a.length;
        for (int i = 0; i < n; i++) {
            int x = Integer.parseInt(a[i]);
            int y = Integer.parseInt(c[i]);
            addLast(x, b[i], y);
        }
    }

    void addLast(int id, String name, int price) {
        //------------------------------------------------------------------------------------
        //------ Start your code here---------------------------------------------------------
        Phone phone = new Phone(id, name, price);
        Node newNode = new Node(phone);
        if (phone.price > 0) {
            if (head == null) {
                head = tail = newNode;
            } else {
                tail.next = newNode;
                newNode.pre = tail;
                tail = tail.next;
            }
            size++;
        }

        //------ End your code here-----------------------------------------------------------
        //------------------------------------------------------------------------------------
    }

    void f1() throws Exception {
        clear();
        loadData(0);
        String fname = "f1.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        ftraverseFW(f);
        ftraverseBW(f);
        f.close();
    }

    void f2() throws Exception {
        clear();
        loadData(0);
        String fname = "f2.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        ftraverseFW(f);
        ftraverseBW(f);
        Phone v = new Phone(7, "V", 8);
        Phone w = new Phone(9, "W", 10);
        //------------------------------------------------------------------------------------
        //------ Start your code here---------------------------------------------------------
        Node v1 = new Node(v);
        Node w1 = new Node(w);

        Node current = head;
        Node after = current.next;
        current.next = v1;
        v1.pre = current;
        v1.next = w1;
        w1.pre = v1;
        w1.next = after;
        after.pre = w1;
        size += 2;
        //------ End your code here-----------------------------------------------------------
        //------------------------------------------------------------------------------------
        ftraverseFW(f);
        ftraverseBW(f);
        f.close();
    }

    void f3() throws Exception {
        clear();
        loadData(0);
        String fname = "f3.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        ftraverseFW(f);
        ftraverseBW(f);
        //------------------------------------------------------------------------------------
        //------ Start your code here---------------------------------------------------------
        Node maxPriceNode = null;
        int maxPrice = Integer.MIN_VALUE;
        Node current = head;
        Node prevMaxPriceNode = null;
        Node pre = null;

        while (current != null) {
            if (current.info.price >= maxPrice) {
                maxPrice = current.info.price;
                maxPriceNode = current;
                prevMaxPriceNode = pre;
            }
            pre = current;
            current = current.next;
        }

        // Delete the last node holding the most expensive Phone
        if (prevMaxPriceNode != null) {
            prevMaxPriceNode.next = maxPriceNode.next;
            if (maxPriceNode.next != null) {
                maxPriceNode.next.pre = prevMaxPriceNode;
            }
            size--;
        } else {
            // If the maxPriceNode is the head node
            head = maxPriceNode.next;
            if (head != null) {
                head.pre = null;
            }
            size--;

        }
        //------ End your code here-----------------------------------------------------------
        //------------------------------------------------------------------------------------
        ftraverseFW(f);
        ftraverseBW(f);
        f.close();
    }

    void f4() throws Exception {
        clear();
        loadData(0);
        String fname = "f4.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        ftraverseFW(f);
        ftraverseBW(f);
        //------------------------------------------------------------------------------------
        //------ Start your code here---------------------------------------------------------
        Node current = head;
        int count = 0;
        while (current.next != null) {
            if (current.info.name.equalsIgnoreCase("S")) {
                count++;
            }

            current = current.next;
        }
        f.writeBytes(String.valueOf(count));

        //------ End your code here-----------------------------------------------------------
        //------------------------------------------------------------------------------------
        f.close();
    }

    void f5() throws Exception {
        clear();
        loadData(0);
        String fname = "f5.txt";
        File g123 = new File(fname);
        if (g123.exists()) {
            g123.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        ftraverseFW(f);
        ftraverseBW(f);
        //------------------------------------------------------------------------------------
        //------ Start your code here---------------------------------------------------------
        if (head != null) {
            // Delete the first node
            Node firstNode = head;
            head = head.next;
            if (head != null) {
                head.pre = null;
            } else {
                tail = null;
            }
            size--;

            // Swap the first and last nodes
            if (firstNode != tail) {
                Node temp = tail.pre;
                tail.pre = firstNode.pre;
                firstNode.pre = temp;
                firstNode.next = tail.next;
                tail.next = firstNode;

                if (firstNode.pre != null) {
                    firstNode.pre.next = firstNode;
                } else {
                    head = firstNode;
                }

                if (tail.next != null) {
                    tail.next.pre = tail;
                } else {
                    tail = tail.next;
                }

                if (firstNode == tail) {
                    tail = firstNode;
                }
            }
        }
        //------ End your code here-----------------------------------------------------------
        //------------------------------------------------------------------------------------
        ftraverseFW(f);
        ftraverseBW(f);
        f.close();
    }

}
